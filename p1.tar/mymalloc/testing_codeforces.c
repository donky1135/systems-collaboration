#include "mymalloc.c"

int main(){
    int k;
    scanf("%d", &k);
    while(k--){
        int t;
        scanf("%d", &t);
        switch(t){
            case 1:
            case 2:
            case 3:
            default:
                
        }
    }
}